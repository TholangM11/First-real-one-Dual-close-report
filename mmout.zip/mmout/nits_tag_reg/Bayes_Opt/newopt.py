import pandas as pd
import numpy as np
from datetime import datetime
import gc
import random
import warnings

from sklearn.metrics import roc_auc_score, confusion_matrix, f1_score, log_loss, roc_curve, auc, accuracy_score, precision_score, recall_score,confusion_matrix
from sklearn.model_selection import KFold, StratifiedKFold, train_test_split
from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import mean_squared_error

import os
import sys
from tqdm import tqdm_notebook as tqdm
import lightgbm as lgb
import optuna
from optuna import Trial


# ## Set python parameters
warnings.simplefilter(action='ignore', category=FutureWarning)
pd.set_option('display.max_columns', None)
np.random.seed(2018)

gcol = 'real_nits_kw'

#Here for posterity
def sig(x,L=1,k=1,xo=0): #general form of logistic regression
    return L/(1 + np.e**(-k*(x-xo)))

def syndrop(x): #adds noise to synthetic drop data based on rate
    #at high x, sig approaches 1, highly likely to return a drop
    if np.random.rand() >= sig(x,k=17,xo=.17):
        return 0
    else:
        return 1  
    

#read in datasets
train = pd.read_csv("../preprocessing/output_data/train_X.csv")
train_y = pd.read_csv("../preprocessing/output_data/train_y.csv")
train_real_values = train_y[train_y.columns[0]].values
del train_y

test = pd.read_csv("../preprocessing/output_data/test_X.csv")
test_y = pd.read_csv("../preprocessing/output_data/test_y.csv")
test_real_values = test_y[test_y.columns[0]].values
del test_y

cats = np.load("../../input_data/historical/new_remapped_labels_2020_10_27.npy",allow_pickle=True).item() #label encoding dict
catsi = [list(test.columns).index(i) for i in cats]

def objective(trial: Trial, fast_check=True, target_meter=0, return_info=False):
    folds = 5
    seed = 666
    shuffle = False
    kf = KFold(n_splits=folds, shuffle=shuffle, random_state=seed)

    y_valid_pred_total = np.zeros(train.shape[0])

    models = []
    valid_score = 0
    for train_idx, valid_idx in kf.split(train,train_real_values):
        train_data = train.iloc[train_idx,:], train_real_values[train_idx]
        valid_data = train.iloc[valid_idx,:], train_real_values[valid_idx]

        print('train', len(train_idx), 'valid', len(valid_idx))
        model, y_pred_valid, log = fit_lgbm(trial, train_data, valid_data, cat_features=cats,seed=seed,
                                            num_rounds=3000)
        y_valid_pred_total[valid_idx] = y_pred_valid
        models.append(model)
        gc.collect()
        valid_score += log["valid/l2"]
        if fast_check:
            break
    valid_score /= len(models)
    if return_info:
        return valid_score, models, y_pred_valid, y_train
    else:
        return valid_score

# Referred https://github.com/pfnet/optuna/blob/master/examples/lightgbm_simple.py

def fit_lgbm(trial, train, val, devices=(-1,), seed=None, cat_features=None, num_rounds=3000):
    """Train Light GBM model"""
    X_train, y_train = train
    X_valid, y_valid = val
    metric = 'l2'
    params = {
        'num_leaves': trial.suggest_int('num_leaves', 2, 600),
        'objective': 'regression',
        'max_depth': trial.suggest_int('max_depth',6,12),
        'learning_rate': trial.suggest_loguniform('learning_rate',1e-3,1e-1),
        "boosting": "gbdt",
        'lambda_l1': trial.suggest_loguniform('lambda_l1', 1e-8, 10.0),
        'lambda_l2': trial.suggest_loguniform('lambda_l2', 1e-8, 10.0),
        "bagging_freq": 5,
        "bagging_fraction": trial.suggest_uniform('bagging_fraction', 0.1, 1.0),
        "feature_fraction": trial.suggest_uniform('feature_fraction', 0.4, 1.0),
        "metric": metric, "num_threads": 8,
        #'max_bin':63, 
        #'gpu_use_dp': False,
        "verbosity": -1, 
        'device': 'cpu', 
        #'gpu_device_id': 1
    }
    
    params['seed'] = seed

    early_stop = 500
    verbose_eval = 500

    d_train = lgb.Dataset(X_train, label=y_train, categorical_feature=cat_features)
    d_valid = lgb.Dataset(X_valid, label=y_valid, categorical_feature=cat_features)
    watchlist = [d_train, d_valid]
    pruning_callback = optuna.integration.LightGBMPruningCallback(trial, 'l2', valid_name='valid_1')    

    print('training LGB:')
    model = lgb.train(params,
                      train_set=d_train,
                      num_boost_round=num_rounds,
                      valid_sets=watchlist,
                      verbose_eval=verbose_eval,
                      early_stopping_rounds=early_stop,
                      callbacks=[pruning_callback])

    # predictions
    y_pred_valid = model.predict(X_valid, num_iteration=model.best_iteration)
    
    print('best_score', model.best_score)
    log = {'train/l2': model.best_score['training']['l2'],
           'valid/l2': model.best_score['valid_1']['l2']}
    return model, y_pred_valid, log

th = 12
tm = th * 60
timeout = tm * 60


study = optuna.create_study(pruner=optuna.pruners.MedianPruner(n_warmup_steps=500))
study.optimize(objective, timeout=timeout)
print('Best trial: score {}, params {}'.format(study.best_trial.value, study.best_trial.params))

trials_df = study.trials_dataframe()
trials_df.to_csv("trial_output.csv")
